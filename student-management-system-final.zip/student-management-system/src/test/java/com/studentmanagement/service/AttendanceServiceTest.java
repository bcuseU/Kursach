package com.studentmanagement.service;

import com.studentmanagement.dto.AttendanceDto;
import com.studentmanagement.model.AttendanceRecord;
import com.studentmanagement.model.AttendanceStatus;
import com.studentmanagement.model.Group;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.AttendanceRepository;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.StudentRepository;
import com.studentmanagement.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Юнит-тесты AttendanceService (журнал посещаемости).
 * Репозитории заменены моками — БД не нужна.
 *
 * Что проверяем:
 *   - отметка создаётся и обновляется (upsert), статусы НБ/ув/неув/Б
 *   - PRESENT не хранится: запись снимается
 *   - куратор не может отмечать студентов чужой группы
 *   - куратор получает данные одним запросом по своей группе
 *   - неверный формат месяца отклоняется
 */
@ExtendWith(MockitoExtension.class)
class AttendanceServiceTest {

    private static final LocalDate DAY = LocalDate.of(2026, 10, 27);

    @Mock private AttendanceRepository attendanceRepository;
    @Mock private StudentRepository studentRepository;
    @Mock private GroupRepository groupRepository;
    @Mock private UserRepository userRepository;

    @InjectMocks private AttendanceService attendanceService;

    private User admin;
    private User curator;
    private Group curatorGroup;
    private Group otherGroup;
    private Student student;

    @BeforeEach
    void setUp() {
        admin = new User("admin", "hash", "Админ", "admin@uni.ru");
        admin.setId(1L);
        admin.setRoles(Set.of("ROLE_ADMIN", "ROLE_USER"));

        curator = new User("curator1", "hash", "Иванов И.И.", "ivanov@uni.ru");
        curator.setId(2L);
        curator.setRoles(Set.of("ROLE_CURATOR", "ROLE_USER"));

        curatorGroup = new Group("ИТ-21", "Информатика", 2);
        curatorGroup.setId(10L);
        curatorGroup.setCurator(curator);

        otherGroup = new Group("ПМ-31", "Прикладная математика", 3);
        otherGroup.setId(20L);

        student = new Student();
        student.setId(5L);
        student.setGroup(curatorGroup);
    }

    private AttendanceDto dto(AttendanceStatus status) {
        return new AttendanceDto(null, 5L, DAY, status, "справка");
    }

    @Test
    @DisplayName("Новая отметка «неув» сохраняется")
    void upsert_createsNewRecord() {
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(studentRepository.findById(5L)).thenReturn(Optional.of(student));
        when(attendanceRepository.findByStudentIdAndDate(5L, DAY)).thenReturn(Optional.empty());

        AttendanceDto result = attendanceService.upsert(dto(AttendanceStatus.UNEXCUSED), "admin");

        ArgumentCaptor<AttendanceRecord> captor = ArgumentCaptor.forClass(AttendanceRecord.class);
        verify(attendanceRepository).save(captor.capture());
        assertEquals(AttendanceStatus.UNEXCUSED, captor.getValue().getStatus());
        assertEquals(DAY, captor.getValue().getDate());
        assertEquals(AttendanceStatus.UNEXCUSED, result.getStatus());
    }

    @Test
    @DisplayName("Повторная отметка на ту же дату обновляет существующую запись")
    void upsert_existingRecord_isUpdated() {
        AttendanceRecord existing = new AttendanceRecord(student, DAY, AttendanceStatus.ABSENT, null);
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(studentRepository.findById(5L)).thenReturn(Optional.of(student));
        when(attendanceRepository.findByStudentIdAndDate(5L, DAY)).thenReturn(Optional.of(existing));

        attendanceService.upsert(dto(AttendanceStatus.ILLNESS), "admin");

        assertEquals(AttendanceStatus.ILLNESS, existing.getStatus());
        assertEquals("справка", existing.getNote());
        verify(attendanceRepository, times(1)).save(existing);
    }

    @Test
    @DisplayName("Статус PRESENT не хранится: существующая отметка удаляется")
    void upsert_present_deletesRecord() {
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(studentRepository.findById(5L)).thenReturn(Optional.of(student));

        AttendanceDto result = attendanceService.upsert(dto(AttendanceStatus.PRESENT), "admin");

        verify(attendanceRepository).deleteByStudentIdAndDate(5L, DAY);
        verify(attendanceRepository, never()).save(any(AttendanceRecord.class));
        assertEquals(AttendanceStatus.PRESENT, result.getStatus());
    }

    @Test
    @DisplayName("Куратор не может отмечать студента чужой группы")
    void curator_cannotMarkForeignStudent() {
        student.setGroup(otherGroup);
        when(userRepository.findByUsername("curator1")).thenReturn(Optional.of(curator));
        when(studentRepository.findById(5L)).thenReturn(Optional.of(student));
        when(groupRepository.findByCurator(curator)).thenReturn(Optional.of(curatorGroup));

        assertThrows(SecurityException.class,
                () -> attendanceService.upsert(dto(AttendanceStatus.ABSENT), "curator1"));
        verify(attendanceRepository, never()).save(any(AttendanceRecord.class));
    }

    @Test
    @DisplayName("Отметка несуществующему студенту → IllegalArgumentException")
    void upsert_unknownStudent_throws() {
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));
        when(studentRepository.findById(5L)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> attendanceService.upsert(dto(AttendanceStatus.ABSENT), "admin"));
    }

    @Test
    @DisplayName("Куратор без фильтра по месяцу получает записи своей группы одним запросом")
    void getForUser_curatorWithoutMonth_usesGroupQuery() {
        AttendanceRecord rec = new AttendanceRecord(student, DAY, AttendanceStatus.EXCUSE, null);
        when(userRepository.findByUsername("curator1")).thenReturn(Optional.of(curator));
        when(groupRepository.findByCurator(curator)).thenReturn(Optional.of(curatorGroup));
        when(attendanceRepository.findByGroup(10L)).thenReturn(List.of(rec));

        List<AttendanceDto> result = attendanceService.getForUser(null, "curator1");

        assertEquals(1, result.size());
        assertEquals(AttendanceStatus.EXCUSE, result.get(0).getStatus());
        verify(attendanceRepository, never()).findAll();
    }

    @Test
    @DisplayName("Неверный формат месяца → IllegalArgumentException")
    void getForUser_invalidMonth_throws() {
        when(userRepository.findByUsername("admin")).thenReturn(Optional.of(admin));

        assertThrows(IllegalArgumentException.class,
                () -> attendanceService.getForUser("октябрь", "admin"));
    }

    @Test
    @DisplayName("Все четыре типа пропусков присутствуют в enum")
    void enum_containsAllAbsenceTypes() {
        assertEquals(AttendanceStatus.ABSENT, AttendanceStatus.valueOf("ABSENT"));
        assertEquals(AttendanceStatus.EXCUSE, AttendanceStatus.valueOf("EXCUSE"));
        assertEquals(AttendanceStatus.UNEXCUSED, AttendanceStatus.valueOf("UNEXCUSED"));
        assertEquals(AttendanceStatus.ILLNESS, AttendanceStatus.valueOf("ILLNESS"));
    }
}
