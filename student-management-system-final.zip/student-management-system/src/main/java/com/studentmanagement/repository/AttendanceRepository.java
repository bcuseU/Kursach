package com.studentmanagement.repository;

import com.studentmanagement.model.AttendanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {

    Optional<AttendanceRecord> findByStudentIdAndDate(Long studentId, LocalDate date);

    void deleteByStudentIdAndDate(Long studentId, LocalDate date);

    List<AttendanceRecord> findByDateBetween(LocalDate from, LocalDate to);

    @Query("SELECT a FROM AttendanceRecord a " +
           "WHERE a.student.group.id = :groupId " +
           "AND a.date BETWEEN :from AND :to")
    List<AttendanceRecord> findByGroupAndDateBetween(@Param("groupId") Long groupId,
                                                      @Param("from") LocalDate from,
                                                      @Param("to") LocalDate to);

    @Query("SELECT a FROM AttendanceRecord a WHERE a.student.group.id = :groupId")
    List<AttendanceRecord> findByGroup(@Param("groupId") Long groupId);

    List<AttendanceRecord> findByStudentId(Long studentId);
}
