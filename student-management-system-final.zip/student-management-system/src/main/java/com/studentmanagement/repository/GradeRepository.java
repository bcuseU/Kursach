package com.studentmanagement.repository;

import com.studentmanagement.model.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface GradeRepository extends JpaRepository<Grade, Long> {

    Optional<Grade> findByStudentIdAndSubjectId(Long studentId, Long subjectId);

    void deleteByStudentIdAndSubjectId(Long studentId, Long subjectId);

    /**
     * Все оценки по предметам указанного семестра — для куратора/админа.
     */
    @Query("SELECT g FROM Grade g WHERE g.subject.semester = :semester")
    List<Grade> findBySemester(@Param("semester") int semester);

    /**
     * Все оценки студентов группы за заданный семестр.
     */
    @Query("SELECT g FROM Grade g " +
           "WHERE g.subject.semester = :semester " +
           "AND g.student.group.id = :groupId")
    List<Grade> findByGroupAndSemester(@Param("groupId") Long groupId,
                                        @Param("semester") int semester);

    List<Grade> findByStudentId(Long studentId);

    void deleteBySubjectId(Long subjectId);
}
