package com.studentmanagement.repository;

import com.studentmanagement.model.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SubjectRepository extends JpaRepository<Subject, Long> {

    /** Предметы, видимые для конкретной группы: свои + устаревшие глобальные (group IS NULL). */
    @Query("SELECT s FROM Subject s " +
           "WHERE s.semester = :semester " +
           "  AND (s.group.id = :groupId OR s.group IS NULL) " +
           "ORDER BY s.name ASC")
    List<Subject> findVisibleForGroup(@Param("semester") int semester,
                                      @Param("groupId") Long groupId);

    /** Поиск конкретного предмета в группе и семестре по имени (без учёта регистра). */
    @Query("SELECT s FROM Subject s " +
           "WHERE LOWER(s.name) = LOWER(:name) " +
           "  AND s.semester = :semester " +
           "  AND ((:groupId IS NULL AND s.group IS NULL) OR s.group.id = :groupId)")
    Optional<Subject> findByNameSemesterGroup(@Param("name") String name,
                                              @Param("semester") int semester,
                                              @Param("groupId") Long groupId);

    @Query("SELECT s FROM Subject s WHERE s.group.id = :groupId ORDER BY s.semester ASC, s.name ASC")
    List<Subject> findByGroupId(@Param("groupId") Long groupId);
}
