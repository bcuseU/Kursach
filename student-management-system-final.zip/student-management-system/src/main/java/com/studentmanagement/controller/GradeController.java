package com.studentmanagement.controller;

import com.studentmanagement.dto.GradeDto;
import com.studentmanagement.service.GradeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
@Tag(name = "Оценки", description = "Успеваемость студентов")
@SecurityRequirement(name = "Bearer Authentication")
public class GradeController {

    private final GradeService gradeService;

    public GradeController(GradeService gradeService) {
        this.gradeService = gradeService;
    }

    @GetMapping
    @Operation(summary = "Оценки доступных пользователю студентов (опционально по семестру)")
    public ResponseEntity<List<GradeDto>> list(@RequestParam(required = false) Integer semester,
                                                Authentication auth) {
        return ResponseEntity.ok(gradeService.getForUser(semester, auth.getName()));
    }

    @PutMapping
    @Operation(summary = "Поставить или обновить оценку (upsert)")
    public ResponseEntity<?> upsert(@Valid @RequestBody GradeDto dto, Authentication auth) {
        try {
            return ResponseEntity.ok(gradeService.upsert(dto, auth.getName()));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping
    @Operation(summary = "Удалить оценку студента по предмету")
    public ResponseEntity<?> delete(@RequestParam Long studentId,
                                     @RequestParam Long subjectId,
                                     Authentication auth) {
        try {
            gradeService.delete(studentId, subjectId, auth.getName());
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
