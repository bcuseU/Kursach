package com.studentmanagement.controller;

import com.studentmanagement.dto.SubjectDto;
import com.studentmanagement.service.SubjectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/subjects")
@Tag(name = "Предметы", description = "Учебные предметы по группам и семестрам")
@SecurityRequirement(name = "Bearer Authentication")
public class SubjectController {

    private final SubjectService subjectService;

    public SubjectController(SubjectService subjectService) {
        this.subjectService = subjectService;
    }

    @GetMapping
    @Operation(summary = "Предметы. По умолчанию — все; при указании groupId+semester возвращает доступные для группы.")
    public ResponseEntity<List<SubjectDto>> list(@RequestParam(required = false) Integer semester,
                                                 @RequestParam(required = false) Long groupId,
                                                 Authentication auth) {
        return ResponseEntity.ok(
            (groupId != null && semester != null)
                ? subjectService.getForGroup(semester, groupId)
                : subjectService.getAllForUser(auth.getName())
        );
    }

    @PostMapping
    @Operation(summary = "Добавить предмет в группу")
    public ResponseEntity<?> create(@Valid @RequestBody SubjectDto dto, Authentication auth) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(subjectService.create(dto, auth.getName()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    @Operation(summary = "Изменить предмет")
    public ResponseEntity<?> update(@PathVariable Long id, @Valid @RequestBody SubjectDto dto, Authentication auth) {
        try {
            return ResponseEntity.ok(subjectService.update(id, dto, auth.getName()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Удалить предмет вместе со всеми оценками")
    public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
        try {
            subjectService.delete(id, auth.getName());
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }
}
