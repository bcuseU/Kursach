package com.studentmanagement.controller;

import com.studentmanagement.dto.AttendanceDto;
import com.studentmanagement.service.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@Tag(name = "Посещаемость", description = "Журнал посещаемости студентов")
@SecurityRequirement(name = "Bearer Authentication")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @GetMapping
    @Operation(summary = "Посещаемость доступных студентов",
        description = "Параметр month опционально: формат yyyy-MM (например 2026-05)")
    public ResponseEntity<List<AttendanceDto>> list(@RequestParam(required = false) String month,
                                                     Authentication auth) {
        return ResponseEntity.ok(attendanceService.getForUser(month, auth.getName()));
    }

    @PutMapping
    @Operation(summary = "Отметить посещаемость (upsert по студент+дата)")
    public ResponseEntity<?> upsert(@Valid @RequestBody AttendanceDto dto, Authentication auth) {
        try {
            return ResponseEntity.ok(attendanceService.upsert(dto, auth.getName()));
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping
    @Operation(summary = "Удалить отметку посещаемости")
    public ResponseEntity<?> delete(@RequestParam Long studentId,
                                     @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                     Authentication auth) {
        try {
            attendanceService.delete(studentId, date, auth.getName());
            return ResponseEntity.noContent().build();
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
