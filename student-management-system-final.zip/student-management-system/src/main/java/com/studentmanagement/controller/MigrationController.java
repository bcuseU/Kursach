package com.studentmanagement.controller;

import com.studentmanagement.dto.MigrationPayloadDto;
import com.studentmanagement.service.MigrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/migrate")
@Tag(name = "Миграция", description = "Одноразовый перенос данных из localStorage в БД")
@SecurityRequirement(name = "Bearer Authentication")
public class MigrationController {

    private final MigrationService migrationService;

    public MigrationController(MigrationService migrationService) {
        this.migrationService = migrationService;
    }

    @PostMapping
    @Operation(summary = "Импортировать данные из localStorage фронтенда")
    public ResponseEntity<Map<String, Object>> migrate(@RequestBody MigrationPayloadDto payload,
                                                        Authentication auth) {
        return ResponseEntity.ok(migrationService.migrate(payload, auth.getName()));
    }
}
