package com.studentmanagement.controller;

import com.studentmanagement.dto.AuthRequest;
import com.studentmanagement.dto.AuthResponse;
import com.studentmanagement.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Аутентификация", description = "Получение JWT-токена, текущий пользователь, смена пароля")
public class AuthController {

    private final AuthService authService;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AuthService authService, PasswordEncoder passwordEncoder) {
        this.authService = authService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    @Operation(
        summary = "Войти в систему",
        description = "Возвращает JWT Bearer токен. Используйте его в кнопке Authorize ↑"
    )
    @ApiResponse(responseCode = "200", description = "Успешно",
        content = @Content(schema = @Schema(implementation = AuthResponse.class)))
    @ApiResponse(responseCode = "401", description = "Неверный логин или пароль")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request) {
        // BadCredentialsException обработает GlobalExceptionHandler
        return ResponseEntity.ok(authService.login(request));
    }

    @GetMapping("/me")
    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Текущий пользователь", description = "Возвращает профиль авторизованного пользователя (с email и группой)")
    public ResponseEntity<AuthResponse> me(Authentication auth) {
        return ResponseEntity.ok(authService.currentUser(auth.getName()));
    }

    @PutMapping("/password")
    @SecurityRequirement(name = "Bearer Authentication")
    @Operation(summary = "Сменить свой пароль",
        description = "Требует ввода текущего пароля. Новый — минимум 6 символов")
    public ResponseEntity<Map<String, String>> changePassword(
            @RequestBody Map<String, String> body,
            Authentication auth) {
        String current = body.getOrDefault("currentPassword", "");
        String fresh = body.getOrDefault("newPassword", "");
        authService.changePassword(auth.getName(), current, fresh, passwordEncoder);
        return ResponseEntity.ok(Map.of("message", "Пароль успешно изменён"));
    }
}
