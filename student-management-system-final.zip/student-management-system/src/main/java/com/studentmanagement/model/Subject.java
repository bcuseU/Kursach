package com.studentmanagement.model;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * Учебный предмет, привязанный к конкретной учебной группе и семестру.
 * Уникальность проверяется на уровне приложения: (group, semester, name).
 * Поле group допускает NULL только для устаревших записей, созданных до
 * перехода на per-group модель — такие предметы видны во всех группах
 * как «глобальные» (backward compatibility).
 */
@Entity
@Table(name = "subjects")
public class Subject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 200)
    private String name;

    @Column(name = "semester", nullable = false)
    private int semester;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, length = 10)
    private SubjectType type = SubjectType.EXAM;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "group_id")
    private Group group;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    public Subject() {}

    public Subject(String name, int semester, SubjectType type) {
        this.name = name;
        this.semester = semester;
        this.type = type;
    }

    public Subject(String name, int semester, SubjectType type, Group group) {
        this.name = name;
        this.semester = semester;
        this.type = type;
        this.group = group;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }

    public SubjectType getType() { return type; }
    public void setType(SubjectType type) { this.type = type; }

    public Group getGroup() { return group; }
    public void setGroup(Group group) { this.group = group; }

    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
