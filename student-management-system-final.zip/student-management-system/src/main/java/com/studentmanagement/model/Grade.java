package com.studentmanagement.model;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * Оценка студента по предмету. На пару (student, subject) хранится ровно одна запись.
 * Значение хранится строкой: "2".."5" для EXAM, "зачёт"/"незачёт" для PASS.
 */
@Entity
@Table(
    name = "grades",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_grades_student_subject",
        columnNames = {"student_id", "subject_id"}
    ),
    indexes = {
        @Index(name = "ix_grades_subject", columnList = "subject_id"),
        @Index(name = "ix_grades_student", columnList = "student_id")
    }
)
public class Grade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    @Column(name = "value", nullable = false, length = 16)
    private String value;

    @Column(name = "graded_at", nullable = false)
    private Instant gradedAt = Instant.now();

    public Grade() {}

    public Grade(Student student, Subject subject, String value) {
        this.student = student;
        this.subject = subject;
        this.value = value;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }

    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }

    public Instant getGradedAt() { return gradedAt; }
    public void setGradedAt(Instant gradedAt) { this.gradedAt = gradedAt; }
}
