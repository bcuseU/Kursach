package com.studentmanagement.model;

/**
 * Статус посещаемости студента за конкретный день.
 * Отсутствие записи трактуется как присутствие. Сохраняем только пропуски.
 * PRESENT — оставлен для обратной совместимости со старыми записями.
 * ABSENT — НБ (не был), EXCUSE — ув (уважительная), UNEXCUSED — неув (неуважительная),
 * ILLNESS — Б (по болезни).
 */
public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    EXCUSE,
    UNEXCUSED,
    ILLNESS
}
