package com.studentmanagement.model;

/**
 * Тип оценивания предмета.
 * EXAM — пятибалльная оценка (2..5).
 * PASS — зачёт / незачёт.
 */
public enum SubjectType {
    EXAM,
    PASS
}
