package com.studentmanagement.dto;

import java.util.Set;

public class AuthResponse {

    private String accessToken;
    private String tokenType = "Bearer";
    private String username;
    private Set<String> roles;
    private Long userId;
    private String fullName;
    private String email;
    private Long groupId;
    private String groupNumber;
    private String groupFaculty;

    public AuthResponse() {}

    public AuthResponse(String accessToken, String username,
                        Set<String> roles, Long userId, String fullName,
                        String email, Long groupId, String groupNumber, String groupFaculty) {
        this.accessToken = accessToken;
        this.username = username;
        this.roles = roles;
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.groupId = groupId;
        this.groupNumber = groupNumber;
        this.groupFaculty = groupFaculty;
    }

    public String getAccessToken() { return accessToken; }
    public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
    public String getTokenType() { return tokenType; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public Set<String> getRoles() { return roles; }
    public void setRoles(Set<String> roles) { this.roles = roles; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Long getGroupId() { return groupId; }
    public void setGroupId(Long groupId) { this.groupId = groupId; }
    public String getGroupNumber() { return groupNumber; }
    public void setGroupNumber(String groupNumber) { this.groupNumber = groupNumber; }
    public String getGroupFaculty() { return groupFaculty; }
    public void setGroupFaculty(String groupFaculty) { this.groupFaculty = groupFaculty; }
}
