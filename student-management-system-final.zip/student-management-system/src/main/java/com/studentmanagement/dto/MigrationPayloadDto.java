package com.studentmanagement.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

/**
 * Полезная нагрузка для разовой миграции данных из localStorage в БД.
 * Структура повторяет то, что хранится на фронтенде в:
 *   sus_subjects   → subjects
 *   sus_grades     → grades  (вложенная мапа: subjectId(String) → studentId(String) → value)
 *   sus_attendance → attendance
 */
public class MigrationPayloadDto {

    /** [{id, name, semester, type:"exam"|"pass"}, ...] */
    private List<LocalSubject> subjects;

    /** { "<localSubjectId>": { "<studentId>": <value> }, ... } */
    private Map<String, Map<String, Object>> grades;

    /** [{studentId, date:"yyyy-MM-dd", status:"present|absent|excuse", note}, ...] */
    private List<LocalAttendance> attendance;

    public List<LocalSubject> getSubjects() { return subjects; }
    public void setSubjects(List<LocalSubject> subjects) { this.subjects = subjects; }
    public Map<String, Map<String, Object>> getGrades() { return grades; }
    public void setGrades(Map<String, Map<String, Object>> grades) { this.grades = grades; }
    public List<LocalAttendance> getAttendance() { return attendance; }
    public void setAttendance(List<LocalAttendance> attendance) { this.attendance = attendance; }

    public static class LocalSubject {
        public Long id;
        public String name;
        public Integer semester;
        public String type;
    }

    public static class LocalAttendance {
        public Long studentId;
        public String date;
        public String status;
        public String note;
        @JsonProperty("id")
        public Long localId;
    }
}
