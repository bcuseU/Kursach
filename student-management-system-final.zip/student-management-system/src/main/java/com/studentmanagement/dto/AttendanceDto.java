package com.studentmanagement.dto;

import com.studentmanagement.model.AttendanceStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class AttendanceDto {

    private Long id;

    @NotNull
    private Long studentId;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;

    @NotNull
    private AttendanceStatus status;

    @Size(max = 500, message = "Комментарий не длиннее 500 символов")
    private String note;

    public AttendanceDto() {}

    public AttendanceDto(Long id, Long studentId, LocalDate date, AttendanceStatus status, String note) {
        this.id = id; this.studentId = studentId; this.date = date; this.status = status; this.note = note;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public AttendanceStatus getStatus() { return status; }
    public void setStatus(AttendanceStatus status) { this.status = status; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}
