package com.studentmanagement.dto;

import com.studentmanagement.model.SubjectType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SubjectDto {

    private Long id;

    @NotBlank(message = "Название обязательно")
    private String name;

    @NotNull @Min(1) @Max(8)
    private Integer semester;

    @NotNull
    private SubjectType type;

    /** ID учебной группы, к которой относится предмет. NULL — устаревший глобальный предмет. */
    private Long groupId;

    public SubjectDto() {}

    public SubjectDto(Long id, String name, Integer semester, SubjectType type, Long groupId) {
        this.id = id; this.name = name; this.semester = semester; this.type = type; this.groupId = groupId;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getSemester() { return semester; }
    public void setSemester(Integer semester) { this.semester = semester; }
    public SubjectType getType() { return type; }
    public void setType(SubjectType type) { this.type = type; }
    public Long getGroupId() { return groupId; }
    public void setGroupId(Long groupId) { this.groupId = groupId; }
}
