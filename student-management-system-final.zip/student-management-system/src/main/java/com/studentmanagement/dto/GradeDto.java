package com.studentmanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class GradeDto {

    @NotNull
    private Long studentId;

    @NotNull
    private Long subjectId;

    @NotBlank
    private String value;       // "2".."5" или "зачёт"/"незачёт"

    public GradeDto() {}

    public GradeDto(Long studentId, Long subjectId, String value) {
        this.studentId = studentId; this.subjectId = subjectId; this.value = value;
    }

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public Long getSubjectId() { return subjectId; }
    public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
}
