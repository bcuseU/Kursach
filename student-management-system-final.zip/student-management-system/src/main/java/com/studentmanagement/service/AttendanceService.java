package com.studentmanagement.service;

import com.studentmanagement.dto.AttendanceDto;
import com.studentmanagement.model.AttendanceRecord;
import com.studentmanagement.model.AttendanceStatus;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.AttendanceRepository;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.StudentRepository;
import com.studentmanagement.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.List;

@Service
@Transactional
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    public AttendanceService(AttendanceRepository attendanceRepository,
                              StudentRepository studentRepository,
                              GroupRepository groupRepository,
                              UserRepository userRepository) {
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    /**
     * Получить посещаемость. Фильтр month ожидает формат "yyyy-MM".
     * Без фильтра — вся доступная пользователю.
     */
    @Transactional(readOnly = true)
    public List<AttendanceDto> getForUser(String month, String username) {
        User user = resolveUser(username);
        boolean isAdmin = user.getRoles().contains("ROLE_ADMIN");

        LocalDate from = null, to = null;
        if (month != null && !month.isBlank()) {
            try {
                YearMonth ym = YearMonth.parse(month);
                from = ym.atDay(1);
                to = ym.atEndOfMonth();
            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("month должен быть в формате yyyy-MM");
            }
        }

        List<AttendanceRecord> records;
        if (isAdmin) {
            records = (from != null) ? attendanceRepository.findByDateBetween(from, to)
                                     : attendanceRepository.findAll();
        } else {
            Long groupId = groupRepository.findByCurator(user).map(g -> g.getId()).orElse(null);
            if (groupId == null) return List.of();
            if (from != null) {
                records = attendanceRepository.findByGroupAndDateBetween(groupId, from, to);
            } else {
                records = attendanceRepository.findByGroup(groupId);
            }
        }
        return records.stream().map(this::toDto).toList();
    }

    public AttendanceDto upsert(AttendanceDto dto, String username) {
        User user = resolveUser(username);
        Student student = studentRepository.findById(dto.getStudentId())
            .orElseThrow(() -> new IllegalArgumentException("Студент не найден"));
        if (!canAccessStudent(user, student)) {
            throw new SecurityException("Нет прав на отметку посещаемости этого студента");
        }

        // PRESENT = «был»: запись не хранится, а существующая отметка снимается
        if (dto.getStatus() == AttendanceStatus.PRESENT) {
            attendanceRepository.deleteByStudentIdAndDate(student.getId(), dto.getDate());
            return new AttendanceDto(null, student.getId(), dto.getDate(), AttendanceStatus.PRESENT, null);
        }

        AttendanceRecord rec = attendanceRepository
            .findByStudentIdAndDate(student.getId(), dto.getDate())
            .orElseGet(() -> new AttendanceRecord(student, dto.getDate(), dto.getStatus(), dto.getNote()));
        rec.setStatus(dto.getStatus());
        rec.setNote(dto.getNote());
        attendanceRepository.save(rec);
        return toDto(rec);
    }

    public void delete(Long studentId, LocalDate date, String username) {
        User user = resolveUser(username);
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new IllegalArgumentException("Студент не найден"));
        if (!canAccessStudent(user, student)) {
            throw new SecurityException("Нет прав на изменение посещаемости этого студента");
        }
        attendanceRepository.deleteByStudentIdAndDate(studentId, date);
    }

    private User resolveUser(String username) {
        return userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalStateException("Пользователь не найден: " + username));
    }

    private boolean canAccessStudent(User user, Student student) {
        if (user.getRoles().contains("ROLE_ADMIN")) return true;
        if (student.getGroup() == null) return false;
        return groupRepository.findByCurator(user)
            .map(g -> g.getId().equals(student.getGroup().getId()))
            .orElse(false);
    }

    private AttendanceDto toDto(AttendanceRecord r) {
        return new AttendanceDto(r.getId(), r.getStudent().getId(),
            r.getDate(), r.getStatus(), r.getNote());
    }
}
