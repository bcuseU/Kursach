package com.studentmanagement.service;

import com.studentmanagement.dto.GradeDto;
import com.studentmanagement.model.Grade;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.Subject;
import com.studentmanagement.model.SubjectType;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.GradeRepository;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.StudentRepository;
import com.studentmanagement.repository.SubjectRepository;
import com.studentmanagement.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public class GradeService {

    private final GradeRepository gradeRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    private static final Set<String> EXAM_VALUES = Set.of("2", "3", "4", "5");
    private static final Set<String> PASS_VALUES = Set.of("зачёт", "незачёт");

    public GradeService(GradeRepository gradeRepository,
                        StudentRepository studentRepository,
                        SubjectRepository subjectRepository,
                        GroupRepository groupRepository,
                        UserRepository userRepository) {
        this.gradeRepository = gradeRepository;
        this.studentRepository = studentRepository;
        this.subjectRepository = subjectRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public List<GradeDto> getForUser(Integer semester, String username) {
        User user = resolveUser(username);
        boolean isAdmin = user.getRoles().contains("ROLE_ADMIN");
        List<Grade> grades;
        if (semester != null) {
            if (isAdmin) {
                grades = gradeRepository.findBySemester(semester);
            } else {
                Long groupId = groupRepository.findByCurator(user).map(g -> g.getId()).orElse(null);
                if (groupId == null) return List.of();
                grades = gradeRepository.findByGroupAndSemester(groupId, semester);
            }
        } else {
            // Без фильтра по семестру: админу — всё, куратору — только своя группа
            if (isAdmin) {
                grades = gradeRepository.findAll();
            } else {
                Long groupId = groupRepository.findByCurator(user).map(g -> g.getId()).orElse(null);
                if (groupId == null) return List.of();
                grades = gradeRepository.findAll().stream()
                    .filter(g -> g.getStudent().getGroup() != null
                              && groupId.equals(g.getStudent().getGroup().getId()))
                    .toList();
            }
        }
        return grades.stream()
            .map(g -> new GradeDto(g.getStudent().getId(), g.getSubject().getId(), g.getValue()))
            .toList();
    }

    public GradeDto upsert(GradeDto dto, String username) {
        User user = resolveUser(username);
        Student student = studentRepository.findById(dto.getStudentId())
            .orElseThrow(() -> new IllegalArgumentException("Студент не найден: " + dto.getStudentId()));
        Subject subject = subjectRepository.findById(dto.getSubjectId())
            .orElseThrow(() -> new IllegalArgumentException("Предмет не найден: " + dto.getSubjectId()));

        if (!canAccessStudent(user, student)) {
            throw new SecurityException("Нет прав на оценивание этого студента");
        }
        validateValue(subject.getType(), dto.getValue());

        Grade grade = gradeRepository.findByStudentIdAndSubjectId(student.getId(), subject.getId())
            .orElseGet(() -> new Grade(student, subject, dto.getValue()));
        grade.setValue(dto.getValue());
        grade.setGradedAt(Instant.now());
        gradeRepository.save(grade);
        return new GradeDto(student.getId(), subject.getId(), grade.getValue());
    }

    public void delete(Long studentId, Long subjectId, String username) {
        User user = resolveUser(username);
        Student student = studentRepository.findById(studentId)
            .orElseThrow(() -> new IllegalArgumentException("Студент не найден"));
        if (!canAccessStudent(user, student)) {
            throw new SecurityException("Нет прав на изменение оценок этого студента");
        }
        gradeRepository.deleteByStudentIdAndSubjectId(studentId, subjectId);
    }

    private void validateValue(SubjectType type, String value) {
        if (type == SubjectType.EXAM && !EXAM_VALUES.contains(value)) {
            throw new IllegalArgumentException("Для экзамена допустимы только значения 2..5");
        }
        if (type == SubjectType.PASS && !PASS_VALUES.contains(value)) {
            throw new IllegalArgumentException("Для зачёта допустимы только «зачёт» или «незачёт»");
        }
    }

    private User resolveUser(String username) {
        return userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalStateException("Пользователь не найден: " + username));
    }

    private boolean canAccessStudent(User user, Student student) {
        if (user.getRoles().contains("ROLE_ADMIN")) return true;
        if (student.getGroup() == null) return false;
        return groupRepository.findByCurator(user)
            .map(g -> g.getId().equals(student.getGroup().getId()))
            .orElse(false);
    }
}
