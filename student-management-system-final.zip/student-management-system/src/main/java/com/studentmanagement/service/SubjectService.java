package com.studentmanagement.service;

import com.studentmanagement.dto.SubjectDto;
import com.studentmanagement.model.Group;
import com.studentmanagement.model.Subject;
import com.studentmanagement.model.SubjectType;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.GradeRepository;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.SubjectRepository;
import com.studentmanagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Предметы привязаны к учебной группе. Куратор управляет предметами только
 * своей группы, администратор — любых. Поле group допускает NULL только для
 * устаревших записей, видимых во всех группах как «глобальные» (backward compatibility).
 */
@Service
@Transactional
public class SubjectService {

    private static final Logger log = LoggerFactory.getLogger(SubjectService.class);

    private final SubjectRepository subjectRepository;
    private final GradeRepository gradeRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    public SubjectService(SubjectRepository subjectRepository,
                          GradeRepository gradeRepository,
                          GroupRepository groupRepository,
                          UserRepository userRepository) {
        this.subjectRepository = subjectRepository;
        this.gradeRepository = gradeRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public List<SubjectDto> getAllForUser(String username) {
        User user = resolveUser(username);
        if (user.getRoles().contains("ROLE_ADMIN")) {
            return subjectRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
        }
        Long gid = groupRepository.findByCurator(user).map(Group::getId).orElse(null);
        if (gid == null) {
            return subjectRepository.findAll().stream()
                .filter(s -> s.getGroup() == null)
                .map(this::toDto).collect(Collectors.toList());
        }
        final Long curatorGid = gid;
        return subjectRepository.findAll().stream()
            .filter(s -> s.getGroup() == null || curatorGid.equals(s.getGroup().getId()))
            .map(this::toDto).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<SubjectDto> getForGroup(int semester, Long groupId) {
        return subjectRepository.findVisibleForGroup(semester, groupId)
            .stream().map(this::toDto).collect(Collectors.toList());
    }

    public SubjectDto create(SubjectDto dto, String username) {
        User user = resolveUser(username);
        Group group = resolveGroupForWrite(user, dto.getGroupId());

        if (subjectRepository.findByNameSemesterGroup(
                dto.getName().trim(), dto.getSemester(),
                group != null ? group.getId() : null).isPresent()) {
            throw new IllegalArgumentException(
                "Предмет «" + dto.getName() + "» уже есть в " + dto.getSemester() + " семестре этой группы");
        }
        Subject s = new Subject(dto.getName().trim(), dto.getSemester(), dto.getType(), group);
        Subject saved = subjectRepository.save(s);
        log.info("Создан предмет: {} (семестр {}, группа {})",
            saved.getName(), saved.getSemester(),
            group != null ? group.getGroupNumber() : "—");
        return toDto(saved);
    }

    public SubjectDto update(Long id, SubjectDto dto, String username) {
        User user = resolveUser(username);
        Subject s = subjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Предмет не найден: " + id));

        if (s.getGroup() != null) {
            assertCanModify(user, s.getGroup().getId());
        }

        Group newGroup = resolveGroupForWrite(user, dto.getGroupId());

        subjectRepository.findByNameSemesterGroup(
                dto.getName().trim(), dto.getSemester(),
                newGroup != null ? newGroup.getId() : null)
            .filter(other -> !other.getId().equals(id))
            .ifPresent(other -> {
                throw new IllegalArgumentException(
                    "Предмет «" + dto.getName() + "» уже есть в " + dto.getSemester() + " семестре этой группы");
            });

        if (s.getType() != dto.getType()) {
            gradeRepository.deleteBySubjectId(id);
            log.info("Тип предмета {} изменён: оценки сброшены", id);
        }

        s.setName(dto.getName().trim());
        s.setSemester(dto.getSemester());
        s.setType(dto.getType());
        s.setGroup(newGroup);
        return toDto(subjectRepository.save(s));
    }

    public void delete(Long id, String username) {
        User user = resolveUser(username);
        Subject s = subjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Предмет не найден: " + id));
        if (s.getGroup() != null) {
            assertCanModify(user, s.getGroup().getId());
        }
        gradeRepository.deleteBySubjectId(id);
        subjectRepository.deleteById(id);
        log.info("Удалён предмет id={} вместе с оценками", id);
    }

    /**
     * Идемпотентный поиск/создание предмета в конкретной группе.
     * Используется при миграции из localStorage.
     */
    public Subject findOrCreate(String name, int semester, SubjectType type, Group group) {
        Long gid = group != null ? group.getId() : null;
        return subjectRepository.findByNameSemesterGroup(name.trim(), semester, gid)
            .orElseGet(() -> subjectRepository.save(new Subject(name.trim(), semester, type, group)));
    }

    private User resolveUser(String username) {
        return userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalStateException("Пользователь не найден: " + username));
    }

    /** Определяет, в какую группу записывать предмет, проверяя права пользователя. */
    private Group resolveGroupForWrite(User user, Long requestedGroupId) {
        boolean isAdmin = user.getRoles().contains("ROLE_ADMIN");
        if (isAdmin) {
            if (requestedGroupId == null) {
                throw new IllegalArgumentException("Для администратора требуется указать группу");
            }
            return groupRepository.findById(requestedGroupId)
                .orElseThrow(() -> new IllegalArgumentException("Группа не найдена: " + requestedGroupId));
        }
        Group curatorGroup = groupRepository.findByCurator(user)
            .orElseThrow(() -> new SecurityException("Куратор не привязан ни к одной группе"));
        if (requestedGroupId != null && !requestedGroupId.equals(curatorGroup.getId())) {
            throw new SecurityException("Куратор может создавать предметы только в своей группе");
        }
        return curatorGroup;
    }

    private void assertCanModify(User user, Long groupId) {
        boolean isAdmin = user.getRoles().contains("ROLE_ADMIN");
        if (isAdmin) return;
        Long curatorGroupId = groupRepository.findByCurator(user).map(Group::getId).orElse(null);
        if (curatorGroupId == null || !curatorGroupId.equals(groupId)) {
            throw new SecurityException("Нет прав на изменение предмета чужой группы");
        }
    }

    private SubjectDto toDto(Subject s) {
        Long gid = s.getGroup() != null ? s.getGroup().getId() : null;
        return new SubjectDto(s.getId(), s.getName(), s.getSemester(), s.getType(), gid);
    }
}
