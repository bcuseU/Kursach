package com.studentmanagement.service;

import com.studentmanagement.dto.MigrationPayloadDto;
import com.studentmanagement.model.AttendanceRecord;
import com.studentmanagement.model.AttendanceStatus;
import com.studentmanagement.model.Grade;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.Subject;
import com.studentmanagement.model.SubjectType;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.AttendanceRepository;
import com.studentmanagement.repository.GradeRepository;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.StudentRepository;
import com.studentmanagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Разовая миграция данных из localStorage фронтенда в БД.
 * Все операции идемпотентные: повторный запуск ничего не сломает.
 */
@Service
@Transactional
public class MigrationService {

    private static final Logger log = LoggerFactory.getLogger(MigrationService.class);

    private final SubjectService subjectService;
    private final GradeRepository gradeRepository;
    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    public MigrationService(SubjectService subjectService,
                            GradeRepository gradeRepository,
                            AttendanceRepository attendanceRepository,
                            StudentRepository studentRepository,
                            GroupRepository groupRepository,
                            UserRepository userRepository) {
        this.subjectService = subjectService;
        this.gradeRepository = gradeRepository;
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    public Map<String, Object> migrate(MigrationPayloadDto payload, String username) {
        User user = resolveUser(username);
        boolean isAdmin = user.getRoles().contains("ROLE_ADMIN");
        Long allowedGroupId = isAdmin ? null
            : groupRepository.findByCurator(user).map(g -> g.getId()).orElse(null);

        int subjectsCreated = 0, subjectsSkipped = 0;
        int gradesCreated = 0, gradesSkipped = 0;
        int attCreated = 0, attSkipped = 0;

        // Локальный subjectId (с фронта) → реальный Subject в БД
        Map<Long, Subject> localToReal = new HashMap<>();

        // Куратор мигрирует предметы в свою группу; админ — оставляет «глобальными» (group=null).
        com.studentmanagement.model.Group migrationGroup = (allowedGroupId != null)
            ? groupRepository.findById(allowedGroupId).orElse(null)
            : null;

        if (payload.getSubjects() != null) {
            for (MigrationPayloadDto.LocalSubject ls : payload.getSubjects()) {
                if (ls.name == null || ls.semester == null) { subjectsSkipped++; continue; }
                SubjectType type = "pass".equalsIgnoreCase(ls.type) ? SubjectType.PASS : SubjectType.EXAM;
                Subject before = subjectService.findOrCreate(ls.name, ls.semester, type, migrationGroup);
                if (before.getCreatedAt() != null
                    && before.getCreatedAt().isAfter(java.time.Instant.now().minusSeconds(5))) {
                    subjectsCreated++;
                } else {
                    subjectsSkipped++;
                }
                if (ls.id != null) localToReal.put(ls.id, before);
            }
        }

        if (payload.getGrades() != null) {
            for (Map.Entry<String, Map<String, Object>> e : payload.getGrades().entrySet()) {
                Long localSubjId;
                try { localSubjId = Long.parseLong(e.getKey()); }
                catch (NumberFormatException ex) { continue; }
                Subject subject = localToReal.get(localSubjId);
                if (subject == null) continue;

                for (Map.Entry<String, Object> g : e.getValue().entrySet()) {
                    Long studentId;
                    try { studentId = Long.parseLong(g.getKey()); }
                    catch (NumberFormatException ex) { continue; }

                    Student student = studentRepository.findById(studentId).orElse(null);
                    if (student == null) { gradesSkipped++; continue; }
                    if (!isAdmin && (student.getGroup() == null
                            || !student.getGroup().getId().equals(allowedGroupId))) {
                        gradesSkipped++; continue;
                    }

                    String value = String.valueOf(g.getValue());
                    if (subject.getType() == SubjectType.EXAM
                        && !value.matches("[2-5]")) { gradesSkipped++; continue; }
                    if (subject.getType() == SubjectType.PASS
                        && !(value.equals("зачёт") || value.equals("незачёт"))) {
                        gradesSkipped++; continue;
                    }

                    if (gradeRepository.findByStudentIdAndSubjectId(student.getId(), subject.getId()).isEmpty()) {
                        gradeRepository.save(new Grade(student, subject, value));
                        gradesCreated++;
                    } else {
                        gradesSkipped++;
                    }
                }
            }
        }

        if (payload.getAttendance() != null) {
            for (MigrationPayloadDto.LocalAttendance la : payload.getAttendance()) {
                if (la.studentId == null || la.date == null || la.status == null) { attSkipped++; continue; }
                LocalDate date;
                try { date = LocalDate.parse(la.date); }
                catch (Exception e) { attSkipped++; continue; }

                Student student = studentRepository.findById(la.studentId).orElse(null);
                if (student == null) { attSkipped++; continue; }
                if (!isAdmin && (student.getGroup() == null
                        || !student.getGroup().getId().equals(allowedGroupId))) {
                    attSkipped++; continue;
                }

                AttendanceStatus status;
                try { status = AttendanceStatus.valueOf(la.status.toUpperCase()); }
                catch (Exception e) { attSkipped++; continue; }

                if (attendanceRepository.findByStudentIdAndDate(student.getId(), date).isEmpty()) {
                    attendanceRepository.save(new AttendanceRecord(student, date, status, la.note));
                    attCreated++;
                } else {
                    attSkipped++;
                }
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("subjects", Map.of("created", subjectsCreated, "skipped", subjectsSkipped));
        result.put("grades", Map.of("created", gradesCreated, "skipped", gradesSkipped));
        result.put("attendance", Map.of("created", attCreated, "skipped", attSkipped));
        log.info("Миграция от {}: {}", username, result);
        return result;
    }

    private User resolveUser(String username) {
        return userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalStateException("Пользователь не найден: " + username));
    }
}
