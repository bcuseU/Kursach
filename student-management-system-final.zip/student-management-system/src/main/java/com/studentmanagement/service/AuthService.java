package com.studentmanagement.service;

import com.studentmanagement.dto.AuthRequest;
import com.studentmanagement.dto.AuthResponse;
import com.studentmanagement.model.Group;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.UserRepository;
import com.studentmanagement.security.JwtTokenProvider;
import com.studentmanagement.security.UserPrincipal;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

/**
 * Сервис аутентификации.
 * AuthenticationManager проверяет логин/пароль через BCrypt,
 * затем генерируем JWT.
 */
@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final GroupRepository groupRepository;

    public AuthService(AuthenticationManager authenticationManager,
                       JwtTokenProvider tokenProvider,
                       UserRepository userRepository,
                       GroupRepository groupRepository) {
        this.authenticationManager = authenticationManager;
        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;
        this.groupRepository = groupRepository;
    }

    public AuthResponse login(AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getUsername(),
                request.getPassword()
            )
        );

        String token = tokenProvider.generateToken(authentication);

        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();

        // Получаем роли из БД (актуальные)
        User user = userRepository.findByUsername(principal.getUsername())
            .orElseThrow();

        Group group = groupRepository.findByCurator(user).orElse(null);

        return new AuthResponse(
            token,
            principal.getUsername(),
            user.getRoles(),
            principal.getId(),
            principal.getFullName(),
            user.getEmail(),
            group != null ? group.getId() : null,
            group != null ? group.getGroupNumber() : null,
            group != null ? group.getFaculty() : null
        );
    }

    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public AuthResponse currentUser(String username) {
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalArgumentException("Пользователь не найден"));
        Group group = groupRepository.findByCurator(user).orElse(null);
        AuthResponse resp = new AuthResponse(
            null,
            user.getUsername(),
            user.getRoles(),
            user.getId(),
            user.getFullName(),
            user.getEmail(),
            group != null ? group.getId() : null,
            group != null ? group.getGroupNumber() : null,
            group != null ? group.getFaculty() : null
        );
        return resp;
    }

    public void changePassword(String username, String currentPassword, String newPassword,
                               org.springframework.security.crypto.password.PasswordEncoder encoder) {
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("Новый пароль должен содержать минимум 6 символов");
        }
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new IllegalArgumentException("Пользователь не найден"));
        if (!encoder.matches(currentPassword, user.getPassword())) {
            throw new BadCredentialsException("Текущий пароль введён неверно");
        }
        user.setPassword(encoder.encode(newPassword));
        userRepository.save(user);
    }
}
