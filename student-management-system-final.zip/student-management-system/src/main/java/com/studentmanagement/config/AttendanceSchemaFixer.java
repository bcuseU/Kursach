package com.studentmanagement.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Hibernate 6 на @Enumerated(STRING) вешает CHECK-констрейнт со списком enum-значений
 * в момент создания таблицы. При расширении enum новые значения нарушают этот CHECK,
 * а ddl-auto: update сам констрейнт не обновляет. Чтобы добавление новых статусов (ILLNESS, UNEXCUSED) не ломало
 * INSERT/UPDATE, при старте удаляем все CHECK-констрейнты на attendance.status —
 * валидация значений теперь полностью на стороне приложения через Java-enum.
 */
@Component
@Order(0) // выполняется до DataInitializer
public class AttendanceSchemaFixer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(AttendanceSchemaFixer.class);

    private final JdbcTemplate jdbc;

    public AttendanceSchemaFixer(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void run(ApplicationArguments args) {
        try {
            List<String> names = jdbc.queryForList(
                "SELECT conname FROM pg_constraint c " +
                "JOIN pg_class t ON t.oid = c.conrelid " +
                "WHERE t.relname = 'attendance' AND c.contype = 'c' " +
                "  AND pg_get_constraintdef(c.oid) ILIKE '%status%'",
                String.class
            );
            for (String name : names) {
                jdbc.execute("ALTER TABLE attendance DROP CONSTRAINT IF EXISTS \"" + name + "\"");
                log.info("✓ Снят устаревший CHECK-констрейнт attendance.{}", name);
            }
        } catch (Exception e) {
            log.warn("AttendanceSchemaFixer: не удалось проверить/снять CHECK на attendance.status ({})", e.getMessage());
        }
    }
}
