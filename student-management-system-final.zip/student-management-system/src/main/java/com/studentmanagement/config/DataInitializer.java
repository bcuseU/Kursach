package com.studentmanagement.config;

import com.studentmanagement.model.Group;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.StudentStatus;
import com.studentmanagement.model.User;
import com.studentmanagement.repository.GroupRepository;
import com.studentmanagement.repository.StudentRepository;
import com.studentmanagement.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Set;

/**
 * Инициализация дефолтных пользователей, групп и студентов при первом запуске.
 * Пароли хранятся в BCrypt-хеше — не в plaintext.
 *
 * Если admin уже создан — повторное наполнение не выполняется
 * (защита от перезаписи продуктовых данных).
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final GroupRepository groupRepository;
    private final StudentRepository studentRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           GroupRepository groupRepository,
                           StudentRepository studentRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.groupRepository = groupRepository;
        this.studentRepository = studentRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        createAdmin();
        // Сидинг полностью идемпотентен: добавляет только то, чего ещё нет.
        // Безопасно запускать на любой БД — существующие данные не трогаются.
        seedDemoData();
        log.info("→ Итог: пользователей {}, групп {}, студентов {}",
            userRepository.count(), groupRepository.count(), studentRepository.count());
    }

    private void createAdmin() {
        if (userRepository.existsByUsername("admin")) return;

        User admin = new User(
            "admin",
            passwordEncoder.encode("admin123"),
            "Администратор системы",
            "admin@university.ru"
        );
        admin.setRoles(Set.of("ROLE_ADMIN", "ROLE_USER"));
        userRepository.save(admin);
        log.info("✓ Создан admin / admin123 (ROLE_ADMIN)");
    }

    /**
     * Создаёт реалистичную демо-выборку: 4 куратора + 4 группы + 20 студентов
     * с разными статусами и заполненными контактами.
     */
    private void seedDemoData() {
        User curator1 = createCurator("curator1", "curator123", "Иванова Ольга Сергеевна",       "ivanova@university.ru");
        User curator2 = createCurator("petrov",   "curator123", "Петров Андрей Николаевич",      "petrov@university.ru");
        User curator3 = createCurator("sidorova", "curator123", "Сидорова Мария Викторовна",     "sidorova@university.ru");
        User curator4 = createCurator("volkov",   "curator123", "Волков Дмитрий Александрович",  "volkov@university.ru");

        Group g1 = createGroup("3-1ИС", "Информационных систем", 3, curator1);
        Group g2 = createGroup("2-1ИС", "Информационных систем", 2, curator2);
        Group g3 = createGroup("4-2ПР", "Программирования",      4, curator3);
        Group g4 = createGroup("1-1ИС", "Информационных систем", 1, curator4);

        addStudent(g1, "Петров",    "Алексей",   "Сергеевич",     "2004-03-15", "ИС-2023-001", "+79161234501", "petrov.a@edu.ru",     "г. Москва, ул. Тверская, д. 1",        StudentStatus.ACTIVE,   "Староста группы, отличник");
        addStudent(g1, "Смирнова",  "Мария",     "Андреевна",     "2004-07-22", "ИС-2023-002", "+79161234502", "smirnova.m@edu.ru",   "г. Москва, ул. Арбат, д. 12, кв. 5",   StudentStatus.ACTIVE,   "Участвует в олимпиадах по программированию");
        addStudent(g1, "Козлов",    "Дмитрий",   "Иванович",      "2003-11-08", "ИС-2023-003", "+79161234503", "kozlov.d@edu.ru",     "г. Москва, Ленинский пр., д. 45",      StudentStatus.ACADEMIC, "Академический отпуск с 01.09.2025");
        addStudent(g1, "Новикова",  "Екатерина", "Павловна",      "2004-05-30", "ИС-2023-004", "+79161234504", "novikova.e@edu.ru",   "г. Москва, ул. Профсоюзная, д. 78",    StudentStatus.ACTIVE,   null);
        addStudent(g1, "Морозов",   "Андрей",    "Олегович",      "2004-01-14", "ИС-2023-005", "+79161234505", "morozov.a@edu.ru",    "г. Москва, ул. Покровка, д. 22",       StudentStatus.ACTIVE,   "Спортсмен, мастер спорта по плаванию");
        addStudent(g1, "Зайцев",    "Игорь",     "Михайлович",    "2003-09-19", "ИС-2023-006", null,            "zaytsev.i@edu.ru",    null,                                    StudentStatus.EXPELLED, "Отчислен за неуспеваемость (приказ от 15.02.2026)");

        addStudent(g2, "Соколова",  "Анна",      "Дмитриевна",    "2005-02-11", "ИС-2024-001", "+79161234507", "sokolova.a@edu.ru",   "г. Москва, ул. Маросейка, д. 7",       StudentStatus.ACTIVE,   "Активный участник студсовета");
        addStudent(g2, "Лебедев",   "Михаил",    "Викторович",    "2005-04-25", "ИС-2024-002", "+79161234508", "lebedev.m@edu.ru",    "г. Москва, Кутузовский пр., д. 30",    StudentStatus.ACTIVE,   null);
        addStudent(g2, "Кузнецова", "Ольга",     "Романовна",     "2005-08-03", "ИС-2024-003", "+79161234509", "kuznetsova.o@edu.ru", "г. Подольск, ул. Кирова, д. 14",       StudentStatus.ACTIVE,   "Хорошие способности к математике");
        addStudent(g2, "Орлов",     "Никита",    "Сергеевич",     "2005-12-17", "ИС-2024-004", "+79161234510", "orlov.n@edu.ru",      "г. Москва, ул. Сретенка, д. 5",        StudentStatus.ACTIVE,   null);
        addStudent(g2, "Васильева", "Полина",    "Игоревна",      "2005-06-09", "ИС-2024-005", "+79161234511", "vasilieva.p@edu.ru",  "г. Балашиха, ул. Свободы, д. 10",      StudentStatus.ACADEMIC, "Академ. отпуск по состоянию здоровья");

        addStudent(g3, "Михайлов",  "Артём",     "Викторович",    "2002-10-05", "ПР-2022-001", "+79161234512", "mikhailov.a@edu.ru",  "г. Москва, ул. Пятницкая, д. 28",      StudentStatus.ACTIVE,   "Защита диплома — июнь 2026");
        addStudent(g3, "Фёдорова",  "Алина",     "Алексеевна",    "2002-12-21", "ПР-2022-002", "+79161234513", "fedorova.a@edu.ru",   "г. Москва, ул. Новый Арбат, д. 15",    StudentStatus.ACTIVE,   "Тема диплома: «Микросервисная архитектура»");
        addStudent(g3, "Степанов",  "Кирилл",    "Дмитриевич",    "2002-04-13", "ПР-2022-003", "+79161234514", "stepanov.k@edu.ru",   "г. Москва, ул. Большая Якиманка, д. 4",StudentStatus.GRADUATE, "Выпущен в феврале 2026 (экстерн)");
        addStudent(g3, "Беляева",   "София",     "Кирилловна",    "2002-08-30", "ПР-2022-004", "+79161234515", "belyaeva.s@edu.ru",   "г. Москва, Дмитровское ш., д. 110",    StudentStatus.ACTIVE,   null);
        addStudent(g3, "Антонов",   "Максим",    "Юрьевич",       "2002-06-18", "ПР-2022-005", "+79161234516", "antonov.m@edu.ru",    "г. Реутов, ул. Победы, д. 8",          StudentStatus.ACTIVE,   "Работает на полставки в IT-компании");

        addStudent(g4, "Григорьева","Виктория",  "Андреевна",     "2006-01-23", "ИС-2025-001", "+79161234517", "grigorieva.v@edu.ru", "г. Москва, Каширское ш., д. 56",       StudentStatus.ACTIVE,   "Поступила с золотой медалью");
        addStudent(g4, "Семёнов",   "Илья",      "Денисович",     "2006-03-07", "ИС-2025-002", "+79161234518", "semenov.i@edu.ru",    "г. Долгопрудный, ул. Лихачевская, д. 4",StudentStatus.ACTIVE,  null);
        addStudent(g4, "Павлова",   "Дарья",     "Васильевна",    "2006-09-14", "ИС-2025-003", "+79161234519", "pavlova.d@edu.ru",    "г. Москва, ул. Лесная, д. 17",         StudentStatus.ACTIVE,   null);
        addStudent(g4, "Романов",   "Глеб",      "Александрович", "2006-11-02", "ИС-2025-004", "+79161234520", "romanov.g@edu.ru",    "г. Химки, Ленинский пр., д. 1",        StudentStatus.ACTIVE,   "Адаптируется к учебной нагрузке");

        log.info("✓ Заполнены демо-данные: 4 куратора, 4 группы, {} студентов",
            studentRepository.count());
    }

    private User createCurator(String username, String password,
                               String fullName, String email) {
        return userRepository.findByUsername(username).orElseGet(() -> {
            User u = new User(username, passwordEncoder.encode(password), fullName, email);
            u.setRoles(Set.of("ROLE_CURATOR", "ROLE_USER"));
            User saved = userRepository.save(u);
            log.info("  · Куратор: {} / {} ({})", username, password, fullName);
            return saved;
        });
    }

    private Group createGroup(String number, String faculty, int course, User curator) {
        return groupRepository.findByGroupNumber(number).orElseGet(() -> {
            Group g = new Group(number, faculty, course);
            g.setCurator(curator);
            Group saved = groupRepository.save(g);
            log.info("  · Группа: {} ({} курс, куратор {})", number, course, curator.getUsername());
            return saved;
        });
    }

    private void addStudent(Group group, String lastName, String firstName, String patronymic,
                            String birthDate, String recordBook, String phone, String email,
                            String address, StudentStatus status, String note) {
        if (studentRepository.existsByRecordBookNumber(recordBook)) return;
        Student s = new Student();
        s.setLastName(lastName);
        s.setFirstName(firstName);
        s.setPatronymic(patronymic);
        s.setBirthDate(birthDate != null ? LocalDate.parse(birthDate) : null);
        s.setRecordBookNumber(recordBook);
        s.setPhoneNumber(phone);
        s.setEmail(email);
        s.setAddress(address);
        s.setStatus(status);
        s.setNote(note);
        s.setGroup(group);
        studentRepository.save(s);
    }
}
