package com.studentmanagement.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * При переходе на per-group предметы старый UNIQUE-констрейнт (name, semester)
 * мешает создавать одноимённые предметы в разных группах. ddl-auto: update
 * новый констрейнт не накладывает и старый не дропает — делаем это вручную
 * при старте. Уникальность теперь обеспечивается валидацией в SubjectService.
 */
@Component
@Order(0)
public class SubjectsSchemaFixer implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(SubjectsSchemaFixer.class);

    private final JdbcTemplate jdbc;

    public SubjectsSchemaFixer(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void run(ApplicationArguments args) {
        try {
            List<String> uniqueOnNameSemester = jdbc.queryForList(
                "SELECT conname FROM pg_constraint c " +
                "JOIN pg_class t ON t.oid = c.conrelid " +
                "WHERE t.relname = 'subjects' AND c.contype = 'u' " +
                "  AND pg_get_constraintdef(c.oid) ILIKE '%(name, semester)%'",
                String.class
            );
            for (String name : uniqueOnNameSemester) {
                jdbc.execute("ALTER TABLE subjects DROP CONSTRAINT IF EXISTS \"" + name + "\"");
                log.info("✓ Снят устаревший UNIQUE-констрейнт subjects.{} (now per-group)", name);
            }
        } catch (Exception e) {
            log.warn("SubjectsSchemaFixer: не удалось проверить/снять UNIQUE на subjects ({})", e.getMessage());
        }
    }
}
