# Student Management System (СУС)

Веб-приложение для куратора и администратора учебного заведения: группы, студенты, успеваемость, посещаемость, заметки. Backend — REST API на **Spring Boot 3.2** + **PostgreSQL** + **JWT**. Frontend — single-page `index.html` (ванильный JS), отдаётся самим Spring Boot из `src/main/resources/static/`.

---

## Возможности

- **Студенты** — карточки с ФИО, контактами, зачётной книжкой, статусом (`ACTIVE` / `ACADEMIC` / `EXPELLED` / `GRADUATE`) и заметками куратора. Фильтры: по группе, по статусу, по успеваемости (5 диапазонов + «есть двойки»), по посещаемости (≥90 / 70–89 / <70 %), сортировка по фамилии А→Я.
- **Группы** — номер, специальность, курс, прикреплённый куратор. Фильтр по курсу. Удалять можно только пустые группы.
- **Успеваемость** — таблица «студенты × предметы» по семестрам. Быстрый ввод: `2`/`3`/`4`/`5` для экзамена, `З`/`+` зачёт, `Н`/`−` незачёт. Навигация `Tab`/`Enter`/стрелки. Кнопки массового заполнения столбца. У администратора таблицы разбиты по группам и отсортированы по убыванию курса.
- **Посещаемость** — школьный журнал на месяц: пустая ячейка = был, клик циклически проставляет **НБ** (не был), **ув** (уважительная), **неув** (неуважительная), **Б** (по болезни). Правый клик — добавить комментарий. Bulk-режим: чекбоксы у студентов + клик по числу дня проставляет «НБ» всем выбранным. Подсчёт пропусков и % посещаемости справа. У администратора отдельный журнал на каждую группу (сортировка 4 → 1 курс) и выбор группы в списке над таблицей. Кнопка **⬇ PDF** выгружает журнал за месяц: откроется окно печати, выберите «Сохранить как PDF».
- **Кураторы и администраторы** — управление учётками (только ADMIN).
- **Профиль** — смена своего пароля.
- **Дашборд** — сводка по группе/системе.

---

## Быстрый старт

### 1. Запустить PostgreSQL

```bash
docker run -d \
  --name student-db \
  -e POSTGRES_DB=student_management \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=1234 \
  -p 5432:5432 \
  postgres:15
```

### 2. Если Maven Central недоступен (РФ) — добавить зеркало в `~/.m2/settings.xml`

```xml
<settings>
  <mirrors>
    <mirror>
      <id>yandex</id>
      <mirrorOf>central</mirrorOf>
      <url>https://mirror.yandex.ru/mirrors/maven/</url>
    </mirror>
  </mirrors>
</settings>
```

### 3. Собрать и запустить

```bash
mvn clean package -DskipTests
mvn spring-boot:run
```

### 4. Открыть

- **Веб-приложение**: <http://localhost:8080/>
- **Swagger UI**: <http://localhost:8080/swagger-ui.html> — нажать **Authorize** → вставить токен из `/api/auth/login`.

---

## Дефолтные пользователи (создаются автоматически)

| Логин    | Пароль     | Роль         |
|----------|------------|--------------|
| admin    | admin123   | ROLE_ADMIN   |
| curator1 | curator123 | ROLE_CURATOR |

Группа **3-1ИС** прикреплена к `curator1`. Пароли хранятся в **BCrypt**.

> В UI на странице входа никаких подсказок с тестовыми паролями нет — это техническая информация только для разработки.

---

## Архитектура

```
src/main/java/com/studentmanagement/
├── Application.java
├── config/
│   ├── SecurityConfig.java          # JWT-фильтр, BCrypt, открытые пути
│   ├── OpenApiConfig.java           # Swagger
│   ├── GlobalExceptionHandler.java  # единая обработка ошибок
│   ├── DataInitializer.java         # сидинг admin + демо-данных
│   └── AttendanceSchemaFixer.java   # авто-снятие старого CHECK на attendance.status
├── controller/    # REST: Auth, Group, Student, User, Subject, Grade, Attendance, Migration
├── service/       # бизнес-логика
├── repository/    # Spring Data JPA
├── model/         # JPA-сущности
├── dto/           # DTO для API
└── security/      # JwtTokenProvider, JwtAuthenticationFilter, UserDetailsServiceImpl
```

Frontend — один файл `src/main/resources/static/index.html` (HTML + CSS + ванильный JS). State хранится в памяти, `localStorage` используется как офлайн-кэш и фоллбэк для демо-режима.

---

## API

### Аутентификация

| Метод | URL                  | Доступ | Описание                                                 |
|-------|----------------------|--------|----------------------------------------------------------|
| POST  | `/api/auth/login`    | Public | Получить JWT                                             |
| GET   | `/api/auth/me`       | Auth   | Текущий пользователь (email, ФИО, прикреплённая группа)  |
| PUT   | `/api/auth/password` | Auth   | Сменить свой пароль (`currentPassword`, `newPassword`)   |

### Группы

| Метод  | URL                          | Доступ | Описание                       |
|--------|------------------------------|--------|--------------------------------|
| GET    | `/api/groups`                | Auth   | Все группы                     |
| GET    | `/api/groups/{id}`           | Auth   | Группа по ID                   |
| GET    | `/api/groups/number/{номер}` | Auth   | Группа по номеру               |
| POST   | `/api/groups`                | ADMIN  | Создать группу                 |
| PUT    | `/api/groups/{id}`           | ADMIN  | Обновить группу                |
| DELETE | `/api/groups/{id}`           | ADMIN  | Удалить группу (только пустые) |

### Студенты

| Метод  | URL                        | Доступ | Описание                                  |
|--------|----------------------------|--------|-------------------------------------------|
| GET    | `/api/students`            | Auth   | Все (ADMIN) или своя группа (CURATOR)     |
| GET    | `/api/students/{id}`       | Auth   | По ID (с проверкой прав)                  |
| GET    | `/api/students/group/{id}` | Auth   | По группе                                 |
| POST   | `/api/students`            | Auth   | Создать (куратор — только свою группу)    |
| PUT    | `/api/students/{id}`       | Auth   | Обновить (с проверкой прав)               |
| DELETE | `/api/students/{id}`       | Auth   | Удалить (с проверкой прав)                |

Поля `StudentDto`: `firstName`, `lastName`, `patronymic`, `birthDate`, `phoneNumber`, `email`, `address`, `recordBookNumber` (уникальный), `status`, `note` (до 1000 символов), `groupId`.

### Кураторы и администраторы

| Метод  | URL              | Доступ | Описание           |
|--------|------------------|--------|--------------------|
| GET    | `/api/users`     | ADMIN  | Все пользователи   |
| POST   | `/api/users`     | ADMIN  | Создать куратора   |
| PUT    | `/api/users/{id}`| ADMIN  | Обновить           |
| DELETE | `/api/users/{id}`| ADMIN  | Удалить            |

### Предметы и оценки

| Метод  | URL                                           | Доступ | Описание                                          |
|--------|-----------------------------------------------|--------|---------------------------------------------------|
| GET    | `/api/subjects`                               | Auth   | Все предметы (для UI всех семестров)              |
| POST   | `/api/subjects`                               | Auth   | Создать предмет (`name`, `semester`, `type`)      |
| PUT    | `/api/subjects/{id}`                          | Auth   | Обновить                                          |
| DELETE | `/api/subjects/{id}`                          | Auth   | Удалить                                           |
| GET    | `/api/grades`                                 | Auth   | Все оценки (доступные пользователю)               |
| PUT    | `/api/grades`                                 | Auth   | Upsert (`studentId`, `subjectId`, `value`)        |
| DELETE | `/api/grades?studentId=…&subjectId=…`         | Auth   | Очистить оценку                                   |

`SubjectType`: `EXAM` (числовая 2–5) / `PASS` (зачёт/незачёт).

### Посещаемость

| Метод  | URL                                            | Доступ | Описание                                                   |
|--------|------------------------------------------------|--------|------------------------------------------------------------|
| GET    | `/api/attendance?month=YYYY-MM`                | Auth   | Все записи (опц. фильтр по месяцу)                         |
| PUT    | `/api/attendance`                              | Auth   | Upsert (`studentId`, `date`, `status`, `note`)             |
| DELETE | `/api/attendance?studentId=…&date=YYYY-MM-DD`  | Auth   | Удалить отметку (= студент присутствовал)                  |

`AttendanceStatus`: `ABSENT` (НБ — не был), `EXCUSE` (ув — уважительная), `UNEXCUSED` (неув — неуважительная), `ILLNESS` (Б — по болезни). Значение `PRESENT` оставлено в enum только для обратной совместимости со старыми данными — новые записи о присутствии не пишутся, **отсутствие записи = студент был**.

### Миграция локальных данных

| Метод | URL            | Доступ | Описание                                                |
|-------|----------------|--------|---------------------------------------------------------|
| POST  | `/api/migrate` | Auth   | Перенести `subjects` / `grades` / `attendance` из браузерного `localStorage` в БД при первом входе |

Срабатывает один раз: после успешной миграции в `localStorage` ставится флаг `sus_migrated_v1=true`.

---

## Эволюция схемы БД

- Используется `ddl-auto: update` — Hibernate сам создаёт и расширяет таблицы при старте.
- В `AttendanceRecord` колонка `status` создавалась как `varchar(10)` + автоматический CHECK-констрейнт со списком enum-значений. При добавлении нового значения (`ILLNESS`, `UNEXCUSED`) CHECK сам не обновляется и блокирует вставку. Компонент `AttendanceSchemaFixer` (`@Order(0)`) на старте находит и снимает устаревший CHECK на `attendance.status`. Валидация значений теперь полностью на стороне приложения через Java-enum.

---

## Запуск тестов

```bash
mvn test
mvn test -Dtest=StudentServiceTest
mvn test -Dtest=JwtTokenProviderTest
mvn test -Dtest=AuthControllerIntegrationTest
```

Тесты используют **H2 in-memory БД** — PostgreSQL для тестов запускать не нужно. Конфиг: `src/test/resources/application.yml`.

### Что тестируется

| Класс                          | Что проверяет                                                                                                  |
|--------------------------------|----------------------------------------------------------------------------------------------------------------|
| `AttendanceServiceTest`        | Отметка создаётся и обновляется; PRESENT снимает запись; куратор не отмечает чужих студентов; выборка по группе; неверный месяц |
| `StudentServiceTest`           | Куратор не может видеть/менять чужих студентов; дублирование зачётки; поля `status` и `note`; defaultный ACTIVE |
| `JwtTokenProviderTest`         | Генерация токена, извлечение username/ролей, отклонение чужой подписи и истёкших токенов                       |
| `AuthControllerIntegrationTest`| HTTP-вход через MockMvc — корректные/неверные учётки, пустое тело                                              |

---

## Переменные окружения

| Переменная       | По умолчанию                                          | Описание                                  |
|------------------|-------------------------------------------------------|-------------------------------------------|
| `JDBC_URL`       | `jdbc:postgresql://localhost:5432/student_management` | URL БД                                    |
| `JDBC_USER`      | `postgres`                                            | Пользователь БД                           |
| `JDBC_PASSWORD`  | `1234`                                                | Пароль БД                                 |
| `JWT_SECRET`     | `pleaseChange...`                                     | Секрет для подписи JWT (минимум 256 бит)  |
| `JWT_EXPIRATION` | `3600000`                                             | Время жизни токена в мс (по умолчанию 1 ч)|
| `SERVER_PORT`    | `8080`                                                | Порт сервера                              |

---

## Примечания по терминологии

В UI поле группы подписано как **«Специальность»**. В БД, DTO и Java-классах оно по историческим причинам называется `faculty` — это техническое имя поля, переименование не требуется и не повлияет на отображение.
